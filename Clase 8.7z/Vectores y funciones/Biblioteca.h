#define LETRAS 50
void mostrar(int[], int[], char[][LETRAS], int);
